export default function Logo(){
    return <h1>Packing List</h1>
  }